#!/bin/bash

# Azure Deployment Script for Oman Tourism Website
# This script deploys the infrastructure and application to Azure

set -e  # Exit on any error

# Configuration
RESOURCE_GROUP_NAME="rg-oman-tourism"
LOCATION="East US"
DEPLOYMENT_NAME="oman-tourism-deployment-$(date +%Y%m%d-%H%M%S)"
TEMPLATE_FILE="azure-templates/azuredeploy.json"
PARAMETERS_FILE="azure-templates/azuredeploy.parameters.json"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if Azure CLI is installed and user is logged in
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check if Azure CLI is installed
    if ! command -v az &> /dev/null; then
        print_error "Azure CLI is not installed. Please install it first."
        print_status "Visit: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
        exit 1
    fi
    
    # Check if user is logged in
    if ! az account show &> /dev/null; then
        print_error "You are not logged in to Azure. Please run 'az login' first."
        exit 1
    fi
    
    print_success "Prerequisites check passed"
}

# Function to create resource group
create_resource_group() {
    print_status "Creating resource group: $RESOURCE_GROUP_NAME"
    
    if az group show --name "$RESOURCE_GROUP_NAME" &> /dev/null; then
        print_warning "Resource group $RESOURCE_GROUP_NAME already exists"
    else
        az group create \
            --name "$RESOURCE_GROUP_NAME" \
            --location "$LOCATION" \
            --output table
        print_success "Resource group created successfully"
    fi
}

# Function to deploy ARM template
deploy_infrastructure() {
    print_status "Deploying infrastructure using ARM template..."
    
    az deployment group create \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$DEPLOYMENT_NAME" \
        --template-file "$TEMPLATE_FILE" \
        --parameters "@$PARAMETERS_FILE" \
        --output table
    
    print_success "Infrastructure deployment completed"
}

# Function to get deployment outputs
get_deployment_outputs() {
    print_status "Retrieving deployment outputs..."
    
    # Get the outputs from the deployment
    WEBAPP_URL=$(az deployment group show \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$DEPLOYMENT_NAME" \
        --query "properties.outputs.webAppUrl.value" \
        --output tsv)
    
    STORAGE_ACCOUNT=$(az deployment group show \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$DEPLOYMENT_NAME" \
        --query "properties.outputs.storageAccountName.value" \
        --output tsv)
    
    ASSETS_URL=$(az deployment group show \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$DEPLOYMENT_NAME" \
        --query "properties.outputs.assetsUrl.value" \
        --output tsv)
    
    print_success "Deployment outputs retrieved"
    echo "Web App URL: $WEBAPP_URL"
    echo "Storage Account: $STORAGE_ACCOUNT"
    echo "Assets URL: $ASSETS_URL"
}

# Function to upload static assets
upload_assets() {
    print_status "Uploading static assets to blob storage..."
    
    # Upload CSS files
    if [ -d "assets/css" ]; then
        az storage blob upload-batch \
            --destination "assets/css" \
            --source "assets/css" \
            --account-name "$STORAGE_ACCOUNT" \
            --overwrite true
        print_success "CSS files uploaded"
    fi
    
    # Upload JavaScript files
    if [ -d "assets/js" ]; then
        az storage blob upload-batch \
            --destination "assets/js" \
            --source "assets/js" \
            --account-name "$STORAGE_ACCOUNT" \
            --overwrite true
        print_success "JavaScript files uploaded"
    fi
    
    # Upload image files
    if [ -d "assets/images" ]; then
        az storage blob upload-batch \
            --destination "assets/images" \
            --source "assets/images" \
            --account-name "$STORAGE_ACCOUNT" \
            --overwrite true
        print_success "Image files uploaded"
    fi
}

# Function to update HTML files with correct URLs
update_html_files() {
    print_status "Updating HTML files with correct blob storage URLs..."
    
    # Replace placeholder URLs in HTML files
    find . -name "*.html" -type f -exec sed -i "s/YOUR_STORAGE_ACCOUNT/$STORAGE_ACCOUNT/g" {} \;
    
    print_success "HTML files updated"
}

# Function to deploy web application
deploy_webapp() {
    print_status "Deploying web application..."
    
    # Get the web app name from parameters
    WEBAPP_NAME=$(cat "$PARAMETERS_FILE" | grep -A 1 '"webAppName"' | grep '"value"' | cut -d'"' -f4)
    
    # Create a deployment package
    zip -r webapp.zip . -x "*.git*" "azure-templates/*" "*.md" "deploy.sh"
    
    # Deploy to Azure Web App
    az webapp deployment source config-zip \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$WEBAPP_NAME" \
        --src webapp.zip
    
    # Clean up
    rm webapp.zip
    
    print_success "Web application deployed"
}

# Function to verify deployment
verify_deployment() {
    print_status "Verifying deployment..."
    
    # Test if the website is accessible
    HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$WEBAPP_URL" || echo "000")
    
    if [ "$HTTP_STATUS" = "200" ]; then
        print_success "Website is accessible and responding correctly (HTTP 200)"
    else
        print_warning "Website returned HTTP status: $HTTP_STATUS"
    fi
    
    print_status "Deployment verification completed"
}

# Function to display final information
display_final_info() {
    echo ""
    echo "=================================================="
    echo "           DEPLOYMENT COMPLETED"
    echo "=================================================="
    echo ""
    echo "🌐 Website URL: $WEBAPP_URL"
    echo "📦 Storage Account: $STORAGE_ACCOUNT"
    echo "🗂️  Assets URL: $ASSETS_URL"
    echo "📁 Resource Group: $RESOURCE_GROUP_NAME"
    echo ""
    echo "Next Steps:"
    echo "1. Visit your website at: $WEBAPP_URL"
    echo "2. Set up GitHub Actions secrets for CI/CD:"
    echo "   - AZURE_CREDENTIALS"
    echo "   - AZURE_RESOURCE_GROUP"
    echo "3. Push your code to GitHub to trigger automated deployment"
    echo ""
    echo "=================================================="
}

# Main execution
main() {
    echo "=================================================="
    echo "    Azure Deployment Script - Oman Tourism"
    echo "=================================================="
    echo ""
    
    check_prerequisites
    create_resource_group
    deploy_infrastructure
    get_deployment_outputs
    upload_assets
    update_html_files
    deploy_webapp
    verify_deployment
    display_final_info
}

# Run the main function
main "$@"

