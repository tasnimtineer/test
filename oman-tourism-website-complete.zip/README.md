# AZ-900 Certification Lab: Deploying Oman Tourism Website with Azure WebApp, GitHub Actions, and Blob Storage

**Author:** Manus AI  
**Date:** June 19, 2025  
**Lab Duration:** 3-4 hours  
**Difficulty Level:** Intermediate  
**Prerequisites:** Basic understanding of web development, Azure fundamentals, and Git

## Executive Summary

This comprehensive laboratory exercise is designed to provide hands-on experience with core Azure services that are essential for the AZ-900 Microsoft Azure Fundamentals certification. The lab focuses on deploying a real-world tourism website for the Sultanate of Oman using a modern cloud architecture that demonstrates Infrastructure as a Service (IaaS), Platform as a Service (PaaS), and Software as a Service (SaaS) concepts.

The exercise encompasses the deployment of a static website using Azure Web Apps, the implementation of a continuous integration and continuous deployment (CI/CD) pipeline through GitHub Actions, and the utilization of Azure Blob Storage for efficient static asset management. This practical approach ensures that learners gain direct experience with Azure's core services while building a functional, responsive website that showcases the natural beauty and cultural heritage of Oman.

Throughout this lab, participants will engage with fundamental Azure concepts including resource groups, App Service plans, storage accounts, and deployment automation. The project demonstrates real-world cloud architecture patterns and best practices that are commonly tested in the AZ-900 certification exam, providing both theoretical understanding and practical implementation experience.

## Learning Objectives

Upon successful completion of this laboratory exercise, participants will have achieved several critical learning outcomes that align directly with AZ-900 certification requirements. The primary objective is to develop a comprehensive understanding of how Azure's core services work together to deliver scalable, reliable web applications in a cloud environment.

Participants will gain hands-on experience with Azure Web Apps, learning how to configure and deploy web applications using Platform as a Service capabilities. This includes understanding the relationship between App Service plans and Web Apps, configuring deployment settings, and managing application lifecycle in a cloud environment. The exercise demonstrates how Azure Web Apps abstract away infrastructure management while providing enterprise-grade hosting capabilities.

The laboratory also provides extensive experience with Azure Blob Storage, teaching participants how to leverage cloud storage for static assets such as images, CSS files, and JavaScript resources. This component of the lab illustrates the cost-effectiveness and scalability benefits of separating static content from dynamic application logic, a common pattern in modern web architecture.

A significant portion of the learning experience focuses on implementing DevOps practices through GitHub Actions integration with Azure services. Participants will configure automated deployment pipelines that demonstrate continuous integration and continuous deployment principles, showing how code changes can be automatically tested, built, and deployed to Azure infrastructure without manual intervention.

The lab emphasizes security best practices throughout the deployment process, including the proper configuration of service principals, the secure management of deployment credentials through GitHub Secrets, and the implementation of HTTPS-only communication. These security considerations are fundamental to the AZ-900 certification and reflect real-world requirements for production deployments.

Resource management concepts are thoroughly explored through the creation and configuration of Azure resource groups, demonstrating how to organize and manage related Azure resources effectively. Participants will learn about resource lifecycle management, cost optimization strategies, and the importance of proper resource organization in enterprise environments.

## Technical Architecture Overview

The technical architecture for this laboratory exercise represents a modern, cloud-native approach to web application deployment that leverages multiple Azure services working in concert. The architecture demonstrates key principles of cloud computing including scalability, reliability, and cost-effectiveness while maintaining simplicity appropriate for foundational learning.

At the core of the architecture is Azure Web Apps, which serves as the primary hosting platform for the Oman tourism website. Azure Web Apps provides a fully managed Platform as a Service environment that eliminates the need for infrastructure management while offering enterprise-grade features such as automatic scaling, load balancing, and integrated monitoring. The Web App is configured to serve the main HTML content and handle user requests, while static assets are offloaded to Azure Blob Storage for optimal performance and cost efficiency.

Azure Blob Storage plays a crucial role in the architecture by hosting all static assets including images, CSS stylesheets, and JavaScript files. This separation of concerns follows cloud architecture best practices by leveraging the most appropriate service for each type of content. Blob Storage provides virtually unlimited scalability, global content distribution capabilities, and cost-effective storage for static content that doesn't require the computational resources of a web server.

The deployment pipeline is orchestrated through GitHub Actions, which provides automated continuous integration and continuous deployment capabilities. The GitHub Actions workflow is triggered by code changes pushed to the main branch of the repository, initiating a series of automated steps that build, test, and deploy both the web application and static assets to their respective Azure services.

Resource organization follows Azure best practices through the use of a dedicated resource group that contains all related resources for the project. This approach simplifies management, enables consistent security policies, and facilitates cost tracking and resource lifecycle management. The resource group includes the App Service plan, Web App, Storage Account, and associated configuration resources.

Security is integrated throughout the architecture through the use of Azure service principals for authentication, HTTPS-only communication, and proper access controls on storage containers. The deployment process utilizes secure credential management through GitHub Secrets, ensuring that sensitive authentication information is never exposed in code repositories or deployment logs.

The architecture also demonstrates important concepts of cloud economics by utilizing Azure's Free tier services where possible, making the lab accessible to learners while illustrating how cloud services can be cost-effectively scaled based on actual usage requirements. The App Service plan uses the F1 (Free) tier for development and learning purposes, while the Storage Account uses Standard locally redundant storage for cost optimization.

## Prerequisites and Environment Setup

Before beginning this laboratory exercise, participants must ensure they have access to the necessary tools, accounts, and foundational knowledge required for successful completion. The prerequisites are designed to be accessible to individuals pursuing the AZ-900 certification while providing the technical foundation necessary for hands-on Azure development.

An active Microsoft Azure subscription is the primary requirement for this lab. Participants can utilize a free Azure account, which provides sufficient credits and access to the services required for this exercise. The free tier includes access to Azure Web Apps (F1 tier), Azure Storage accounts, and other essential services needed for the lab. For educational institutions or corporate training environments, Azure for Students or Azure Enterprise subscriptions provide additional benefits and extended access to Azure services.

A GitHub account is essential for implementing the continuous integration and continuous deployment pipeline that forms a core component of this exercise. GitHub provides free accounts with sufficient repository storage and GitHub Actions minutes for educational and small-scale development projects. Participants should be familiar with basic Git operations including cloning repositories, committing changes, and pushing code to remote repositories.

Local development environment setup requires several tools that are commonly used in modern web development workflows. A text editor or integrated development environment capable of editing HTML, CSS, and JavaScript files is necessary. Popular options include Visual Studio Code, which provides excellent integration with Azure services and GitHub, or other editors such as Sublime Text or Atom. The Azure CLI (Command Line Interface) should be installed and configured for local development and testing of deployment scripts.

Web browser access is required for testing the deployed website and accessing the Azure portal for resource management. Modern browsers such as Chrome, Firefox, Safari, or Edge provide the necessary capabilities for interacting with Azure services and viewing the deployed website across different devices and screen sizes.

Foundational knowledge requirements include basic understanding of HTML, CSS, and JavaScript for web development concepts. While the lab provides complete code examples, participants should understand the structure and purpose of web technologies to fully appreciate the deployment process and troubleshooting procedures. Familiarity with basic command-line operations is helpful for running deployment scripts and Azure CLI commands.

Understanding of fundamental cloud computing concepts as covered in AZ-900 study materials provides important context for the services and architectural patterns demonstrated in this lab. This includes knowledge of Infrastructure as a Service (IaaS), Platform as a Service (PaaS), and Software as a Service (SaaS) models, as well as basic understanding of cloud benefits such as scalability, reliability, and cost-effectiveness.

Network connectivity requirements include reliable internet access for downloading dependencies, accessing Azure services, and pushing code to GitHub repositories. The lab involves uploading images and other assets to Azure Blob Storage, so adequate bandwidth is important for efficient completion of the exercise.

## Azure Services Deep Dive

This laboratory exercise provides comprehensive exposure to several core Azure services that are fundamental to the AZ-900 certification and modern cloud application development. Understanding these services in depth is crucial for both certification success and practical cloud implementation skills.

Azure Web Apps represents one of the most important Platform as a Service offerings in the Azure ecosystem. Web Apps provides a fully managed hosting environment for web applications, eliminating the need for virtual machine management while providing enterprise-grade features and scalability. In this lab, Azure Web Apps serves as the primary hosting platform for the Oman tourism website, demonstrating how developers can focus on application logic rather than infrastructure management.

The Web App service automatically handles many operational concerns including load balancing, auto-scaling based on demand, security patching of the underlying operating system, and integration with other Azure services. The service supports multiple programming languages and frameworks including .NET, Java, Node.js, Python, and PHP, though this lab focuses on static HTML content to maintain simplicity and broad accessibility.

App Service plans define the computational resources and features available to Web Apps, representing a crucial concept for understanding Azure's pricing and resource allocation models. The lab utilizes the F1 (Free) tier App Service plan, which provides limited computational resources suitable for development and learning purposes. Understanding the relationship between App Service plans and Web Apps is essential for the AZ-900 certification, as it demonstrates how Azure abstracts infrastructure while providing granular control over resource allocation and costs.

Azure Blob Storage serves as the foundation for scalable, cost-effective storage of unstructured data in Azure. In this lab, Blob Storage hosts all static assets including images, CSS files, and JavaScript resources, demonstrating a common architectural pattern that separates static content from dynamic application logic. This separation provides several benefits including improved performance through content delivery network integration, reduced costs by using appropriate storage tiers for different content types, and enhanced scalability by leveraging Azure's global storage infrastructure.

Blob Storage containers provide logical organization for stored objects, similar to folders in a traditional file system but with additional features such as access policies, metadata, and integration with Azure's security and monitoring services. The lab demonstrates the configuration of public blob access, which allows direct access to static assets from web browsers while maintaining security through proper access controls.

The storage account represents the top-level namespace for Azure Storage services, providing a unique namespace accessible from anywhere in the world via HTTP or HTTPS. Storage accounts also define replication options, performance tiers, and access tiers that affect both cost and availability characteristics. The lab uses Standard locally redundant storage (LRS) for cost optimization while providing adequate durability for development and learning purposes.

Azure Resource Groups provide logical containers for organizing related Azure resources, enabling consistent management, security policies, and cost tracking. Resource groups are fundamental to Azure's resource management model and represent a key concept for the AZ-900 certification. In this lab, all resources are organized within a single resource group, demonstrating how to maintain clean resource organization and simplify lifecycle management.

Resource groups also enable role-based access control (RBAC) at the group level, allowing administrators to grant permissions to entire sets of related resources rather than managing permissions individually. This capability is crucial for enterprise environments where multiple teams may need different levels of access to various Azure resources.

GitHub Actions integration with Azure demonstrates the implementation of DevOps practices in cloud environments, showing how continuous integration and continuous deployment pipelines can automate the software delivery process. The GitHub Actions workflow in this lab automatically deploys both the web application and static assets whenever code changes are pushed to the repository, eliminating manual deployment steps and reducing the potential for human error.

The integration between GitHub Actions and Azure relies on service principals, which are Azure Active Directory identities that can be granted specific permissions to Azure resources. This authentication mechanism demonstrates important security concepts including the principle of least privilege and the separation of user identities from automated system identities.



## Step-by-Step Implementation Guide

The implementation of this laboratory exercise follows a structured approach that builds understanding progressively while demonstrating real-world deployment practices. Each step is designed to reinforce key Azure concepts while providing practical experience with cloud services and DevOps practices.

### Phase 1: Azure Infrastructure Setup

The initial phase focuses on establishing the foundational Azure infrastructure required to host the Oman tourism website. This phase demonstrates fundamental Azure concepts including resource organization, service configuration, and security setup that are essential for the AZ-900 certification.

Begin by accessing the Azure portal through a web browser and signing in with your Azure account credentials. The Azure portal provides a comprehensive interface for managing Azure resources and serves as the primary tool for configuring cloud services. Navigate to the resource groups section and create a new resource group named "rg-oman-tourism" in your preferred Azure region. The choice of region affects both performance and cost, with regions closer to your target audience typically providing better performance characteristics.

Resource group creation establishes the logical container for all resources associated with this project. When creating the resource group, consider the naming conventions and tagging strategies that will be used throughout the project. Consistent naming helps with resource organization and cost tracking, while tags provide additional metadata for resource management and billing allocation.

After creating the resource group, proceed to create the Azure Storage Account that will host static assets for the website. Navigate to the Storage Accounts service in the Azure portal and initiate the creation process. Configure the storage account with a globally unique name such as "omantourismsa" followed by a random number to ensure uniqueness across all Azure storage accounts worldwide.

Select the Standard performance tier and Locally Redundant Storage (LRS) replication option to optimize costs while providing adequate durability for development and learning purposes. Configure the storage account to allow blob public access, which is necessary for serving static assets directly to web browsers. This configuration demonstrates important concepts about data accessibility and security in cloud storage services.

Within the storage account, create a blob container named "assets" with public blob access level. This container will store all static assets including images, CSS files, and JavaScript resources. The public access configuration allows these assets to be accessed directly via HTTP requests from web browsers, demonstrating how cloud storage can serve as a content delivery mechanism.

The next step involves creating the App Service Plan that will define the computational resources available to the web application. Navigate to the App Service Plans section in the Azure portal and create a new plan named "oman-tourism-plan" using the F1 (Free) tier. The Free tier provides limited resources but is sufficient for development and learning purposes while demonstrating the relationship between App Service Plans and Web Apps.

Understanding App Service Plans is crucial for the AZ-900 certification as they represent how Azure abstracts infrastructure management while providing control over resource allocation and costs. The App Service Plan defines the region, operating system, pricing tier, and scaling characteristics that will be available to all Web Apps associated with the plan.

Create the Azure Web App within the previously created App Service Plan. Name the Web App "oman-tourism-app" followed by a unique identifier to ensure global uniqueness. Configure the Web App to use the Linux operating system and select the appropriate runtime stack for static websites. The Web App creation process demonstrates how Platform as a Service offerings abstract infrastructure complexity while providing enterprise-grade hosting capabilities.

Configure the Web App settings to enable HTTPS-only communication, which is a security best practice for all web applications. This configuration ensures that all communication between users and the application is encrypted, protecting sensitive information and improving search engine optimization rankings.

### Phase 2: Local Development Environment Configuration

The second phase focuses on setting up the local development environment and preparing the website code for deployment. This phase demonstrates how local development workflows integrate with cloud deployment processes and emphasizes the importance of testing before deployment.

Clone or download the provided website code to your local development machine. The code includes a responsive website showcasing Oman's tourism attractions, complete with HTML pages, CSS stylesheets, JavaScript functionality, and high-quality images of Oman's landmarks and natural beauty.

Examine the website structure to understand how static assets are referenced and organized. The HTML files contain placeholder URLs that will be replaced with actual Azure Blob Storage URLs during the deployment process. This approach demonstrates how applications can be configured for different environments while maintaining clean separation between code and configuration.

Install the Azure CLI on your local development machine if not already present. The Azure CLI provides command-line access to Azure services and is essential for automating deployment processes. Verify the installation by running authentication commands and testing connectivity to your Azure subscription.

Configure the Azure CLI with your subscription credentials using the login command. This authentication process establishes the security context for subsequent Azure operations and demonstrates how automated tools can securely interact with cloud services using proper authentication mechanisms.

Test the local website by opening the HTML files in a web browser. While the static asset references will not work locally due to the placeholder URLs, this testing verifies that the basic HTML structure and layout are functioning correctly. Local testing is an important practice that helps identify issues before deployment to cloud environments.

Review the provided deployment scripts and GitHub Actions workflow files to understand the automation processes that will be used for deployment. The deployment script demonstrates how Azure CLI commands can be combined to create comprehensive deployment automation, while the GitHub Actions workflow shows how continuous integration and continuous deployment can be implemented using cloud-native tools.

### Phase 3: GitHub Repository Setup and Configuration

The third phase establishes the GitHub repository and configures the continuous integration and continuous deployment pipeline that will automate the deployment process. This phase demonstrates modern DevOps practices and shows how version control systems integrate with cloud deployment processes.

Create a new GitHub repository for the Oman tourism website project. Initialize the repository with appropriate settings including a README file, .gitignore file for web development projects, and an appropriate license if desired. The repository will serve as the central location for code storage and the trigger point for automated deployments.

Upload the website code to the GitHub repository using Git commands or the GitHub web interface. Ensure that all files are properly committed including the HTML pages, CSS stylesheets, JavaScript files, images, deployment scripts, and GitHub Actions workflow files. Proper version control practices are essential for maintaining code quality and enabling collaborative development.

Configure GitHub Secrets to store sensitive Azure credentials that will be used by the GitHub Actions workflow. Navigate to the repository settings and create secrets for Azure authentication including the service principal credentials, resource group name, and other configuration values required for deployment.

The service principal creation process demonstrates important Azure security concepts including identity and access management. Create a service principal using the Azure CLI with appropriate permissions for the resource group containing the tourism website resources. The service principal provides a secure way for automated systems to authenticate with Azure services without using personal user credentials.

Configure the GitHub Actions workflow file to reference the appropriate secrets and environment variables. The workflow file demonstrates how continuous integration and continuous deployment pipelines can be defined using declarative configuration, making the deployment process repeatable and version-controlled.

Test the GitHub Actions workflow by making a small change to the website code and pushing the change to the main branch. Monitor the workflow execution through the GitHub Actions interface to verify that all steps complete successfully and that the website is properly deployed to Azure.

### Phase 4: Deployment Execution and Verification

The final implementation phase focuses on executing the deployment process and verifying that all components are functioning correctly. This phase demonstrates the end-to-end deployment workflow and provides experience with troubleshooting common deployment issues.

Execute the deployment script from your local development environment to perform the initial deployment of Azure infrastructure and application code. The script automates the creation of all necessary Azure resources and deploys the website code to the Web App while uploading static assets to Blob Storage.

Monitor the deployment process through both the command-line output and the Azure portal to understand how the various Azure services are configured and connected. The deployment process demonstrates how Infrastructure as Code principles can be applied to create reproducible, consistent deployments across different environments.

Verify that the Azure Web App is properly serving the website by accessing the provided URL in a web browser. Test the website functionality across different devices and browsers to ensure that the responsive design is working correctly and that all static assets are loading properly from Azure Blob Storage.

Check the Azure Blob Storage container to verify that all static assets have been uploaded correctly and are accessible via their public URLs. This verification demonstrates how cloud storage services can be used to serve static content efficiently and cost-effectively.

Test the GitHub Actions workflow by making additional changes to the website code and verifying that the automated deployment process updates both the Web App and Blob Storage content appropriately. This testing demonstrates the continuous deployment capabilities and shows how code changes can be automatically propagated to production environments.

Monitor the Azure resources through the Azure portal to understand resource utilization, costs, and performance characteristics. The monitoring capabilities demonstrate how cloud services provide visibility into application performance and resource consumption, enabling data-driven optimization decisions.

Configure any additional monitoring or alerting that may be appropriate for the deployment. While not required for the basic lab exercise, understanding monitoring options demonstrates important operational considerations for production deployments.

## Security Considerations and Best Practices

Security represents a fundamental aspect of cloud computing that is extensively covered in the AZ-900 certification and is crucial for real-world Azure deployments. This laboratory exercise incorporates multiple security best practices and demonstrates how security can be integrated throughout the development and deployment lifecycle.

Authentication and authorization form the foundation of cloud security, and this lab demonstrates several important concepts in these areas. The use of service principals for GitHub Actions authentication shows how automated systems can securely access Azure resources without using personal user credentials. Service principals represent Azure Active Directory identities that can be granted specific permissions to Azure resources, implementing the principle of least privilege by providing only the minimum permissions necessary for the required operations.

The configuration of GitHub Secrets for storing sensitive authentication information demonstrates secure credential management practices. Secrets are encrypted at rest and in transit, and are only accessible to authorized workflows and users. This approach prevents sensitive information from being exposed in code repositories or deployment logs, which is a common security vulnerability in many development projects.

HTTPS-only configuration for the Azure Web App ensures that all communication between users and the application is encrypted using Transport Layer Security (TLS). This encryption protects sensitive information from interception and tampering, and is considered a fundamental requirement for all web applications. The lab demonstrates how to configure HTTPS enforcement at the Azure service level, ensuring that even if developers forget to implement HTTPS redirects in application code, the infrastructure will enforce secure communication.

Azure Blob Storage security is configured to allow public read access to static assets while preventing unauthorized modifications. This configuration demonstrates how cloud storage services can provide granular access controls that balance accessibility with security. The public blob access level allows web browsers to directly access static assets for optimal performance while preventing unauthorized users from modifying or deleting content.

Resource group organization provides security benefits by enabling consistent application of security policies across related resources. Role-based access control (RBAC) can be applied at the resource group level, allowing administrators to grant appropriate permissions to different users or groups based on their responsibilities. This approach simplifies security management and reduces the risk of misconfigured permissions.

Network security considerations include the default HTTPS enforcement and the use of Azure's global content delivery network capabilities for static asset delivery. While this lab uses basic networking configurations appropriate for learning purposes, production deployments would typically include additional network security measures such as virtual networks, network security groups, and application gateways.

Data protection is addressed through the use of Azure's built-in encryption capabilities for both storage and transit. Azure Blob Storage automatically encrypts data at rest using Microsoft-managed encryption keys, while HTTPS enforcement ensures encryption in transit. Understanding these encryption capabilities is important for the AZ-900 certification and for meeting compliance requirements in production environments.

Monitoring and auditing capabilities are built into Azure services and provide visibility into resource access and configuration changes. Azure Activity Log records all resource management operations, while Azure Monitor provides performance and availability monitoring. These capabilities enable security teams to detect and respond to potential security issues quickly.

The deployment automation process includes security scanning and validation steps that help identify potential security issues before they reach production environments. The GitHub Actions workflow can be extended to include security scanning tools, dependency vulnerability checks, and compliance validation to ensure that security requirements are met throughout the development lifecycle.

Regular security updates and patch management are handled automatically by Azure Web Apps, which demonstrates one of the key benefits of Platform as a Service offerings. The underlying operating system and runtime environment are automatically updated with security patches, reducing the operational burden on development teams while maintaining security posture.

## Cost Optimization Strategies

Understanding cost optimization in cloud environments is a crucial skill for the AZ-900 certification and for successful cloud adoption in real-world scenarios. This laboratory exercise demonstrates several cost optimization strategies while maintaining functionality and performance requirements.

The selection of Azure service tiers represents the most fundamental cost optimization decision in this lab. The F1 (Free) tier App Service Plan provides sufficient computational resources for development and learning purposes while minimizing costs. Understanding the relationship between service tiers, performance characteristics, and costs is essential for making informed decisions about cloud resource allocation.

Azure Blob Storage cost optimization is achieved through the selection of appropriate storage tiers and replication options. The lab uses Standard performance tier with Locally Redundant Storage (LRS) replication, which provides the lowest cost option while maintaining adequate durability for development purposes. Production deployments might require different replication options based on availability and disaster recovery requirements, but understanding the cost implications of these choices is crucial for effective cloud cost management.

The separation of static assets from dynamic application logic provides cost optimization benefits by leveraging the most appropriate Azure service for each type of content. Serving static assets from Azure Blob Storage is significantly more cost-effective than serving them from Azure Web Apps, especially as traffic volume increases. This architectural pattern demonstrates how proper service selection can provide both performance and cost benefits.

Resource organization through resource groups enables effective cost tracking and management. Azure provides detailed billing information at the resource group level, allowing organizations to understand costs associated with specific projects or applications. The lab demonstrates how consistent resource organization supports cost visibility and accountability.

Automated deployment processes contribute to cost optimization by reducing the time and effort required for manual deployment tasks. The GitHub Actions workflow eliminates the need for manual deployment procedures, reducing operational costs and the potential for human error. Automation also enables more frequent deployments with lower overhead, supporting agile development practices.

Monitoring and alerting capabilities in Azure enable proactive cost management by providing visibility into resource utilization and spending patterns. While not implemented in the basic lab exercise, Azure Cost Management tools can provide spending alerts, budget controls, and optimization recommendations that help organizations maintain cost discipline in cloud environments.

The use of Infrastructure as Code principles through ARM templates and deployment scripts enables consistent, repeatable deployments that reduce the risk of resource misconfiguration and associated costs. Automated resource provisioning also enables easy cleanup of development and testing environments, preventing unnecessary ongoing costs from forgotten resources.

Scaling considerations are important for understanding how costs change with usage patterns. Azure Web Apps provide automatic scaling capabilities that can adjust resource allocation based on demand, ensuring that applications can handle traffic spikes while minimizing costs during low-usage periods. Understanding these scaling options is important for both the AZ-900 certification and for designing cost-effective production systems.

Development and testing cost optimization can be achieved through the use of Azure's free tier services and development-specific pricing options. Many Azure services provide free usage tiers that are sufficient for development and learning purposes, allowing developers to gain experience with cloud services without incurring significant costs.

## Troubleshooting Common Issues

Effective troubleshooting skills are essential for working with cloud services and are frequently tested in Azure certification exams. This section provides guidance for resolving common issues that may arise during the laboratory exercise and demonstrates systematic approaches to problem resolution.

Authentication and authorization issues represent some of the most common problems encountered when working with Azure services. If the GitHub Actions workflow fails with authentication errors, verify that the service principal credentials are correctly configured in GitHub Secrets and that the service principal has appropriate permissions for the target resource group. Use the Azure CLI to test service principal authentication locally before troubleshooting the GitHub Actions workflow.

Service principal permission issues can be resolved by reviewing the role assignments in the Azure portal and ensuring that the service principal has Contributor access to the resource group containing the tourism website resources. The principle of least privilege should be followed, but insufficient permissions will prevent the deployment workflow from completing successfully.

Azure Web App deployment failures may occur due to various factors including incorrect configuration, resource conflicts, or service limitations. Check the deployment logs in the Azure portal to identify specific error messages and root causes. Common issues include naming conflicts with existing resources, quota limitations in free tier subscriptions, and incorrect runtime configuration.

Static asset upload issues to Azure Blob Storage may result from incorrect container configuration, authentication problems, or network connectivity issues. Verify that the blob container is configured with appropriate public access levels and that the storage account allows blob public access. Test asset uploads manually using the Azure CLI to isolate whether the issue is with the automated workflow or the underlying Azure configuration.

GitHub Actions workflow failures can be diagnosed by examining the workflow execution logs in the GitHub Actions interface. Each step in the workflow provides detailed output that can help identify where failures occur. Common issues include missing secrets, incorrect environment variable configuration, and Azure CLI authentication problems.

Website functionality issues after deployment may result from incorrect static asset URLs, missing files, or configuration problems. Use browser developer tools to examine network requests and identify which resources are failing to load. Verify that the HTML files have been correctly updated with the actual Azure Blob Storage URLs rather than placeholder values.

Performance issues with the deployed website may be related to Azure service tier limitations, inefficient static asset organization, or network connectivity problems. The F1 (Free) tier App Service Plan has limited computational resources and may exhibit slower response times compared to paid tiers. Monitor resource utilization through the Azure portal to understand performance characteristics.

DNS and domain name issues may arise if custom domains are configured for the Azure Web App. Verify DNS configuration and SSL certificate settings if custom domains are used. The default Azure-provided domain should work without additional configuration for the basic lab exercise.

Resource cleanup issues may occur when attempting to delete Azure resources that have dependencies or are currently in use. Follow the proper sequence for resource deletion, typically starting with dependent resources before deleting parent resources. Resource groups can be deleted to remove all contained resources simultaneously, but this operation cannot be undone.

Billing and cost-related issues may arise if Azure resources exceed free tier limitations or if unexpected charges occur. Monitor Azure spending through the Azure portal and set up billing alerts to prevent unexpected costs. Understand the limitations of free tier services and the conditions under which charges may apply.

Network connectivity issues may prevent proper communication between Azure services or between local development environments and Azure. Verify firewall settings, network security group configurations, and ensure that required ports are accessible. Azure services typically use standard HTTP and HTTPS ports, but some services may require additional network configuration.

Version control and Git-related issues may prevent proper code synchronization between local development environments and GitHub repositories. Verify Git configuration, authentication credentials, and repository permissions. Ensure that all required files are properly committed and pushed to the repository before expecting automated deployments to occur.

## Performance Monitoring and Optimization

Performance monitoring represents a critical aspect of cloud application management that is covered in Azure certification exams and is essential for maintaining high-quality user experiences. This laboratory exercise provides opportunities to explore Azure's monitoring capabilities and understand how performance data can be used to optimize application behavior.

Azure Web Apps provide built-in monitoring capabilities through Azure Monitor, which collects performance metrics, application logs, and availability data automatically. The Azure portal provides dashboards and charts that display key performance indicators including response times, request rates, error rates, and resource utilization. Understanding these metrics is important for identifying performance bottlenecks and optimization opportunities.

Application Insights integration with Azure Web Apps provides detailed application performance monitoring including request tracing, dependency tracking, and user behavior analytics. While not required for the basic lab exercise, Application Insights demonstrates how cloud services can provide deep visibility into application performance and user experience.

Static asset performance can be monitored through Azure Blob Storage metrics, which provide information about request rates, bandwidth utilization, and error rates for blob storage operations. The separation of static assets from dynamic application logic enables independent monitoring and optimization of each component.

Content delivery network (CDN) integration with Azure Blob Storage can significantly improve performance for users located far from the primary Azure region. CDN services cache static content at edge locations worldwide, reducing latency and improving user experience. Understanding CDN concepts is important for the AZ-900 certification and for designing globally distributed applications.

Performance testing tools can be used to evaluate website performance under various load conditions. Azure provides load testing services that can simulate user traffic and identify performance limitations. While not included in the basic lab exercise, understanding load testing concepts demonstrates how cloud services can be validated for production readiness.

Database performance considerations become important as applications grow beyond static content to include dynamic data storage and retrieval. Azure provides various database services including Azure SQL Database, Cosmos DB, and Azure Database for MySQL, each with different performance characteristics and optimization strategies.

Caching strategies can significantly improve application performance by reducing the need to regenerate or retrieve frequently accessed content. Azure provides various caching services including Azure Cache for Redis and Azure CDN caching capabilities. Understanding when and how to implement caching is important for designing high-performance cloud applications.

Auto-scaling capabilities in Azure Web Apps enable applications to automatically adjust resource allocation based on demand patterns. Auto-scaling rules can be configured based on various metrics including CPU utilization, memory usage, and request rates. This capability ensures that applications can handle traffic spikes while minimizing costs during low-usage periods.

Geographic distribution strategies can improve performance for global user bases by deploying application components in multiple Azure regions. Azure Traffic Manager provides DNS-based load balancing that can route users to the nearest or best-performing application instance. Understanding global distribution concepts is important for designing applications that serve international audiences.

Performance optimization best practices include minimizing HTTP requests, optimizing image sizes and formats, implementing compression, and using efficient coding practices. The tourism website in this lab demonstrates several of these practices including responsive design, optimized images, and efficient CSS and JavaScript organization.

Monitoring alerts and notifications can be configured to proactively identify performance issues before they impact users. Azure Monitor supports various alerting mechanisms including email notifications, SMS messages, and webhook integrations. Proactive monitoring enables rapid response to performance degradation and helps maintain high availability.

## Scaling and High Availability Considerations

Scalability and high availability represent fundamental cloud computing concepts that are extensively covered in the AZ-900 certification and are crucial for designing production-ready applications. This laboratory exercise provides a foundation for understanding these concepts and demonstrates how Azure services support scalable, highly available architectures.

Azure Web Apps provide built-in scaling capabilities that can automatically adjust computational resources based on demand patterns. Vertical scaling (scaling up) involves moving to higher-performance App Service Plan tiers with more CPU, memory, and storage resources. Horizontal scaling (scaling out) involves running multiple instances of the application across multiple servers, with Azure automatically distributing incoming requests across available instances.

Auto-scaling rules can be configured based on various performance metrics including CPU utilization, memory usage, request rates, and custom application metrics. These rules enable applications to automatically respond to changing demand without manual intervention, ensuring optimal performance while minimizing costs. Understanding auto-scaling concepts is important for designing applications that can handle unpredictable traffic patterns.

Load balancing is automatically provided by Azure Web Apps when multiple instances are running, distributing incoming requests across available instances to ensure optimal resource utilization and response times. Azure's load balancing capabilities include health monitoring, automatic failover, and session affinity options that support various application architectures.

High availability in Azure is achieved through multiple layers of redundancy including regional availability zones, paired regions, and service-level redundancy features. Azure Web Apps automatically provide high availability within a single region, while multi-region deployments can provide protection against regional outages.

Azure Blob Storage provides built-in redundancy options including Locally Redundant Storage (LRS), Zone Redundant Storage (ZRS), Geo-Redundant Storage (GRS), and Read-Access Geo-Redundant Storage (RA-GRS). Each option provides different levels of durability and availability, with corresponding cost implications. Understanding these options is important for making informed decisions about data protection requirements.

Disaster recovery planning involves designing applications and data storage strategies that can recover from various types of failures including hardware failures, software bugs, human errors, and natural disasters. Azure provides various disaster recovery services and capabilities that can be integrated into application architectures to meet specific recovery time and recovery point objectives.

Global distribution strategies enable applications to serve users worldwide with optimal performance and availability. Azure's global infrastructure includes dozens of regions worldwide, enabling applications to be deployed close to users regardless of geographic location. Azure Traffic Manager provides DNS-based routing that can direct users to the nearest or best-performing application instance.

Database scaling considerations become important as applications grow to include dynamic data storage requirements. Azure provides various database services with different scaling characteristics, from single-instance databases to globally distributed, multi-master database systems. Understanding database scaling options is important for designing data-intensive applications.

Content delivery network (CDN) integration provides global distribution of static content with automatic caching and optimization. Azure CDN can significantly improve performance for users located far from the primary application region while reducing load on origin servers. CDN services also provide additional availability benefits by serving cached content even if origin servers become unavailable.

Monitoring and alerting systems play crucial roles in maintaining high availability by enabling rapid detection and response to performance issues or failures. Azure Monitor provides comprehensive monitoring capabilities including availability monitoring, performance tracking, and automated alerting. Effective monitoring strategies enable proactive identification of potential issues before they impact users.

Backup and recovery strategies ensure that application data and configuration can be restored in case of failures or data corruption. Azure provides various backup services including automated database backups, blob storage versioning, and application-level backup capabilities. Understanding backup and recovery concepts is important for designing resilient applications.

Testing strategies for scalability and high availability include load testing, failover testing, and disaster recovery testing. These testing approaches help validate that applications can handle expected load levels and recover appropriately from various types of failures. Azure provides testing services and tools that support comprehensive validation of application resilience.

## Integration with Other Azure Services

Understanding how Azure services integrate with each other is crucial for the AZ-900 certification and for designing comprehensive cloud solutions. This laboratory exercise provides a foundation for exploring various integration patterns and demonstrates how multiple Azure services can work together to create robust, scalable applications.

Azure Active Directory (Azure AD) integration provides enterprise-grade identity and access management capabilities for web applications. While not implemented in the basic lab exercise, Azure AD can provide single sign-on, multi-factor authentication, and role-based access control for web applications hosted on Azure Web Apps. Understanding Azure AD concepts is important for designing secure, enterprise-ready applications.

Azure Key Vault integration enables secure storage and management of application secrets, certificates, and encryption keys. Production deployments typically use Key Vault to store database connection strings, API keys, and other sensitive configuration information rather than storing these values in application configuration files or environment variables.

Azure SQL Database integration provides scalable, managed database services for applications that require dynamic data storage and retrieval. The tourism website could be enhanced to include features such as user reviews, booking systems, or content management capabilities that would require database integration. Understanding database integration patterns is important for designing data-driven applications.

Azure Cosmos DB provides globally distributed, multi-model database capabilities that can support applications with complex data requirements and global user bases. Cosmos DB offers multiple consistency models, automatic scaling, and integration with various programming languages and frameworks.

Azure Functions integration enables serverless computing capabilities that can extend web applications with event-driven functionality. Functions can be triggered by various events including HTTP requests, storage operations, and timer schedules, providing cost-effective ways to implement background processing and API endpoints.

Azure Logic Apps provide workflow automation capabilities that can integrate web applications with external services and systems. Logic Apps support hundreds of connectors for popular services including Office 365, Salesforce, Twitter, and many others, enabling complex integration scenarios without custom code development.

Azure API Management provides comprehensive API gateway capabilities including request routing, authentication, rate limiting, and analytics. API Management can be used to create consistent, secure APIs that abstract underlying service implementations and provide developer-friendly interfaces for application integration.

Azure Service Bus provides reliable messaging capabilities for building distributed applications that need to communicate asynchronously. Service Bus supports various messaging patterns including queues, topics, and subscriptions, enabling loose coupling between application components.

Azure Event Grid provides event-driven architecture capabilities that enable applications to react to events from various Azure services and custom sources. Event Grid supports serverless architectures and microservices patterns by providing reliable event delivery and routing.

Azure Cognitive Services provide artificial intelligence and machine learning capabilities that can enhance web applications with features such as image recognition, natural language processing, and speech services. The tourism website could be enhanced with features such as automatic image tagging, language translation, or chatbot capabilities.

Azure Search provides full-text search capabilities that can enhance web applications with sophisticated search functionality. Search services can index content from various sources and provide fast, relevant search results with features such as faceted navigation, auto-complete, and geographic search.

Azure Content Delivery Network (CDN) integration provides global content distribution capabilities that can significantly improve performance for users worldwide. CDN services automatically cache static content at edge locations and provide optimization features such as compression and image optimization.

Azure Application Gateway provides advanced load balancing and application delivery capabilities including SSL termination, URL-based routing, and Web Application Firewall (WAF) protection. Application Gateway can provide additional security and performance benefits for production web applications.

Azure Front Door provides global load balancing and application acceleration capabilities with built-in security features. Front Door can route traffic to the best-performing backend based on various criteria and provides protection against common web application attacks.

Monitoring and logging integration across Azure services provides comprehensive visibility into application performance and behavior. Azure Monitor can collect data from multiple services and provide unified dashboards, alerting, and analytics capabilities that support effective application management.

## Conclusion and Next Steps

This comprehensive laboratory exercise provides hands-on experience with core Azure services that are fundamental to the AZ-900 Microsoft Azure Fundamentals certification while demonstrating real-world cloud application deployment patterns. The implementation of the Oman tourism website showcases how Platform as a Service offerings, cloud storage services, and DevOps automation can work together to create scalable, cost-effective web applications.

The exercise demonstrates key cloud computing concepts including Infrastructure as a Service (IaaS), Platform as a Service (PaaS), and Software as a Service (SaaS) models through practical implementation rather than theoretical discussion. Participants gain direct experience with Azure Web Apps, Azure Blob Storage, GitHub Actions integration, and Azure resource management, providing a solid foundation for understanding cloud service capabilities and limitations.

Security considerations are integrated throughout the exercise, demonstrating how cloud security can be implemented through service configuration, access controls, and automation rather than as an afterthought. The use of service principals, HTTPS enforcement, and secure credential management illustrates best practices that are applicable to production deployments.

Cost optimization strategies are demonstrated through appropriate service tier selection, architectural patterns that leverage the most cost-effective services for each type of content, and automation that reduces operational overhead. Understanding these cost considerations is crucial for successful cloud adoption in real-world scenarios.

The DevOps integration through GitHub Actions demonstrates how modern software development practices can be implemented in cloud environments, showing how continuous integration and continuous deployment can improve software quality while reducing manual effort and the potential for human error.

For participants preparing for the AZ-900 certification, this exercise provides practical experience with many of the concepts and services that are covered in the exam. The hands-on approach reinforces theoretical knowledge and provides confidence in working with Azure services in real-world scenarios.

Next steps for extending this laboratory exercise could include implementing additional Azure services such as Azure SQL Database for dynamic content, Azure Cognitive Services for enhanced functionality, or Azure CDN for improved global performance. These extensions would provide additional learning opportunities while demonstrating more complex cloud architecture patterns.

Production deployment considerations would include implementing more sophisticated monitoring and alerting, configuring custom domains and SSL certificates, implementing backup and disaster recovery strategies, and optimizing performance for expected traffic levels. These considerations demonstrate how development and learning environments can be evolved into production-ready systems.

The skills and knowledge gained through this exercise provide a foundation for pursuing more advanced Azure certifications and for implementing cloud solutions in professional environments. The combination of theoretical understanding and practical experience creates a solid foundation for continued learning and professional development in cloud computing.

## References

[1] Microsoft Azure Documentation - Azure Web Apps Overview  
https://docs.microsoft.com/en-us/azure/app-service/overview

[2] Microsoft Azure Documentation - Azure Blob Storage Introduction  
https://docs.microsoft.com/en-us/azure/storage/blobs/storage-blobs-introduction

[3] GitHub Actions Documentation - Building and Testing  
https://docs.github.com/en/actions/building-and-testing

[4] Microsoft Azure Documentation - Azure Resource Manager Templates  
https://docs.microsoft.com/en-us/azure/azure-resource-manager/templates/

[5] Microsoft Azure Documentation - Azure CLI Reference  
https://docs.microsoft.com/en-us/cli/azure/

[6] Microsoft Learn - AZ-900 Azure Fundamentals Learning Path  
https://docs.microsoft.com/en-us/learn/paths/azure-fundamentals/

[7] Microsoft Azure Documentation - Azure Security Best Practices  
https://docs.microsoft.com/en-us/azure/security/fundamentals/best-practices-and-patterns

[8] Microsoft Azure Documentation - Azure Cost Management  
https://docs.microsoft.com/en-us/azure/cost-management-billing/

[9] Microsoft Azure Documentation - Azure Monitor Overview  
https://docs.microsoft.com/en-us/azure/azure-monitor/overview

[10] GitHub Actions Documentation - Deploying to Azure  
https://docs.github.com/en/actions/deployment/deploying-to-azure

