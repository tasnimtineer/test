# Quick Setup Guide

## Prerequisites
- Azure subscription (free tier sufficient)
- GitHub account
- Azure CLI installed locally
- Git installed locally

## Quick Start Steps

### 1. Clone Repository
```bash
git clone <your-repo-url>
cd oman-tourism-website
```

### 2. Azure Setup
```bash
# Login to Azure
az login

# Create resource group
az group create --name rg-oman-tourism --location "East US"

# Deploy infrastructure
./deploy.sh
```

### 3. GitHub Setup
1. Fork this repository to your GitHub account
2. Go to repository Settings > Secrets and variables > Actions
3. Add the following secrets:
   - `AZURE_CREDENTIALS`: Service principal JSON
   - `AZURE_RESOURCE_GROUP`: rg-oman-tourism

### 4. Create Service Principal
```bash
az ad sp create-for-rbac --name "oman-tourism-sp" \
  --role contributor \
  --scopes /subscriptions/{subscription-id}/resourceGroups/rg-oman-tourism \
  --sdk-auth
```

### 5. Deploy via GitHub Actions
1. Push code to main branch
2. GitHub Actions will automatically deploy
3. Check Actions tab for deployment status

## Environment Variables to Update

In the GitHub Actions workflow (`.github/workflows/main.yml`), update:
- `AZURE_WEBAPP_NAME`: Your unique web app name
- `AZURE_STORAGE_ACCOUNT`: Your unique storage account name

## Verification

After deployment:
1. Visit your Azure Web App URL
2. Verify images load from Blob Storage
3. Test responsive design on mobile devices

## Cleanup

To remove all resources:
```bash
az group delete --name rg-oman-tourism --yes --no-wait
```

## Troubleshooting

### Common Issues:
1. **Authentication errors**: Verify service principal credentials
2. **Name conflicts**: Ensure globally unique names for storage/web app
3. **Permission errors**: Check service principal has Contributor role
4. **Asset loading issues**: Verify blob container public access

### Useful Commands:
```bash
# Check deployment status
az webapp show --name <webapp-name> --resource-group rg-oman-tourism

# View storage account details
az storage account show --name <storage-name> --resource-group rg-oman-tourism

# List blob containers
az storage container list --account-name <storage-name>
```

## Support

For issues related to this lab:
1. Check Azure portal for resource status
2. Review GitHub Actions logs
3. Verify Azure CLI authentication
4. Ensure all prerequisites are met

